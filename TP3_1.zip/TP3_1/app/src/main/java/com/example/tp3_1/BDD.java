package com.example.tp3_1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BDD extends SQLiteOpenHelper {

    private static final int BASE_VERSION = 1;
    private static final String BASE_NOM = "inscription.db";


    private static final String TABLE_USERS = "table_users";
    //ID
    public static final String COLONNE_ID = "id";
    //Login
    public static final String COLONNE_LOGIN = "login";
    //Mot de passe
    public static final String COLONNE_MDP = "mdp";
    //Nom
    public static final String COLONNE_NOM = "nom";
    //Prenom
    public static final String COLONNE_PRENOM = "prenom";
    //Date Of Birth
    public static final String COLONNE_DOB = "dob";
    //Telephone
    public static final String COLONNE_TEL = "telephone";
    //Mail
    public static final String COLONNE_MAIL = "mail";


    private static final String TABLE_USER_INTERESTS = "table_user_interests";
    //Interests
    public static final String COLONNE_INTEREST = "interest";


    private static final String REQUETE_CREATION_TABLE_USER = "create table IF NOT EXISTS "
            + TABLE_USERS + " ("
            + COLONNE_ID + " integer primary key autoincrement, "
            + COLONNE_LOGIN + " text not null unique, "
            + COLONNE_MDP + " text not null, "
            + COLONNE_NOM + " text not null, "
            + COLONNE_PRENOM + " text not null, "
            + COLONNE_DOB + " text not null, "
            + COLONNE_TEL + " text not null, "
            + COLONNE_MAIL + " text not null);";

    private static final String REQUETE_CREATION_TABLE_USER_INTERESTS = "create table IF NOT EXISTS "
            + TABLE_USER_INTERESTS + " ("
            + COLONNE_LOGIN + " text not null, "
            + COLONNE_INTEREST + " text not null, "
            + "PRIMARY KEY (" + COLONNE_LOGIN + ", " + COLONNE_INTEREST +" ));";



    public BDD(Context context, String nom, SQLiteDatabase.CursorFactory cursorfactory, int version) {
        super(context, nom, cursorfactory, version);
    }

    public static void dropTables(SQLiteDatabase db){
        db.execSQL("drop table IF EXISTS '" + TABLE_USERS + "';");
        db.execSQL("drop table IF EXISTS '" + TABLE_USER_INTERESTS + "';");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(REQUETE_CREATION_TABLE_USER);
        db.execSQL(REQUETE_CREATION_TABLE_USER_INTERESTS);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Dans notre cas, nous supprimons la base et les données pour en
        // créer une nouvelle ensuite.
        db.execSQL("drop table IF EXISTS " + TABLE_USERS + ";");
        db.execSQL("drop table IF EXISTS " + TABLE_USER_INTERESTS + ";");

        // Création de la nouvelle structure.
        onCreate(db);
    }

}
