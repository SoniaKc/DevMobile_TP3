package com.example.tp3_1;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class Fragment1 extends Fragment {
    private static final String TABLE_USERS = "table_users";
    //Login
    public static final String COLONNE_LOGIN = "login";
    //Mot de passe
    public static final String COLONNE_MDP = "mdp";
    //Nom
    public static final String COLONNE_NOM = "nom";
    //Prenom
    public static final String COLONNE_PRENOM = "prenom";
    //Date Of Birth
    public static final String COLONNE_DOB = "dob";
    //Telephone
    public static final String COLONNE_TEL = "telephone";
    //Mail
    public static final String COLONNE_MAIL = "mail";

    private static final String TABLE_USER_INTERESTS = "table_user_interests";


    public Fragment1(){
        super(R.layout.fragment1);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragment1View = inflater.inflate(R.layout.fragment1, container, false);

        // Création BDD
        BDD bddCommunicator = new BDD(inflater.getContext(),"BDD_TP3",null,1);
        BDD.dropTables(bddCommunicator.getWritableDatabase());
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();


        Button valider = fragment1View.findViewById(R.id.valider);
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                String login = ((EditText) fragment1View.findViewById(R.id.login)).getText().toString();
                String mdp = ((EditText) fragment1View.findViewById(R.id.mdp)).getText().toString();
                String nom = ((EditText) fragment1View.findViewById(R.id.nom)).getText().toString();
                String prenom = ((EditText) fragment1View.findViewById(R.id.prenom)).getText().toString();
                String dob = ((EditText) fragment1View.findViewById(R.id.dob)).getText().toString();
                String tel = ((EditText) fragment1View.findViewById(R.id.tel)).getText().toString();
                String mail = ((EditText) fragment1View.findViewById(R.id.mail)).getText().toString();

                // Checkboxes des intérêts
                Boolean sport = ((CheckBox) fragment1View.findViewById(R.id.cbSport)).isChecked();
                Boolean musique = ((CheckBox) fragment1View.findViewById(R.id.cbMusique)).isChecked();
                Boolean lecture = ((CheckBox) fragment1View.findViewById(R.id.cbLecture)).isChecked();
                Boolean theatre = ((CheckBox) fragment1View.findViewById(R.id.cbTheatre)).isChecked();
                Boolean photographie = ((CheckBox) fragment1View.findViewById(R.id.cbPhoto)).isChecked();
                Boolean peinture = ((CheckBox) fragment1View.findViewById(R.id.cbPeinture)).isChecked();
                Boolean informatique = ((CheckBox) fragment1View.findViewById(R.id.cbInfo)).isChecked();


                db.execSQL("INSERT INTO " + TABLE_USERS + " ('"
                        + COLONNE_LOGIN + "','" + COLONNE_MDP + "','" + COLONNE_NOM + "','"
                        + COLONNE_PRENOM + "','" + COLONNE_DOB + "','" + COLONNE_TEL + "','"
                        + COLONNE_MAIL + "') VALUES ('"
                        + login + "','" + mdp + "','" + nom + "','" + prenom + "','"
                        + dob + "','" + tel + "','" + mail +"');");

                /*
                Cursor cID = db.query(TABLE_USERS,
                        new String[] {
                                COLONNE_ID_USER},
                        COLONNE_LOGIN + "= '" + login + "' AND " + COLONNE_MDP + "= '" + mdp + "'", null, null,
                        null, null);

                cID.moveToFirst();
                int userID = cID.getInt(0);
                cID.close();
                 */

                if (sport){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Sport');");
                }
                if (musique){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Musique');");
                }
                if (lecture){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Lecture');");
                }
                if (theatre){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Théâtre');");
                }
                if (photographie){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Photographie');");
                }
                if (peinture){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Peinture');");
                }
                if (informatique){
                    db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                            + login + "', 'Informatique');");
                }

                // Passage au fragment 2
                Fragment2 fragment2 = new Fragment2();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.fragmentCV, fragment2);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });

        return fragment1View;
    }
}
