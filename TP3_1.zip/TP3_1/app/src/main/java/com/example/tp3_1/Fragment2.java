package com.example.tp3_1;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;


public class Fragment2 extends Fragment {

    private static final String TABLE_USERS = "table_users";
    public static final String COLONNE_LOGIN = "login";
    private static final String TABLE_USER_INTERESTS = "table_user_interests";
    public static final String COLONNE_INTEREST = "interest";


    public Fragment2(){
        super(R.layout.fragment2);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragment2View = inflater.inflate(R.layout.fragment2, container, false);

        // Chargement BDD
        BDD bddCommunicator = new BDD(inflater.getContext(),"BDD_TP3",null,1);
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();


        // Récupérer le dernier tuple inséré
        Cursor cLastUser = db.rawQuery("SELECT * FROM '" + TABLE_USERS + "' ORDER BY id DESC LIMIT 1",null);

        String lastUserLogin = "";
        if (cLastUser.moveToFirst()){
            lastUserLogin = cLastUser.getString(1);
            ((TextView) fragment2View.findViewById(R.id.login)).append(" "+lastUserLogin);
            ((TextView) fragment2View.findViewById(R.id.nom)).append(" "+cLastUser.getString(3));
            ((TextView) fragment2View.findViewById(R.id.prenom)).append(" "+cLastUser.getString(4));
            ((TextView) fragment2View.findViewById(R.id.dob)).append(" "+cLastUser.getString(5));
            ((TextView) fragment2View.findViewById(R.id.tel)).append(" "+cLastUser.getString(6));
            ((TextView) fragment2View.findViewById(R.id.mail)).append(" "+cLastUser.getString(7));
        }
        cLastUser.close();

        TextView interests = (TextView) fragment2View.findViewById(R.id.interets);

        Cursor cInterests = db.query(TABLE_USER_INTERESTS,
                new String[] {COLONNE_INTEREST},
                COLONNE_LOGIN + "='" + lastUserLogin + "'" , null, null,
                null, null);


        if (cInterests.moveToFirst()) {
            do {
                interests.append(" "+cInterests.getString(0) + '\n');
            } while (cInterests.moveToNext());
            cInterests.close();
        }


        return fragment2View;
    }
}
