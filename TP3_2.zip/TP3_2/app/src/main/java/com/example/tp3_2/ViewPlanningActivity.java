package com.example.tp3_2;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class ViewPlanningActivity extends AppCompatActivity {

    // TABLE PLANNING
    private static final String TABLE_USER_PLANNING = "table_user_planning";
    //Login
    public static final String COLONNE_LOGIN = "login";
    //Date
    public static final String COLONNE_DATE = "date";
    //Créneau 1
    public static final String COLONNE_CRENEAU_1 = "creneau1";
    //Créneau 2
    public static final String COLONNE_CRENEAU_2 = "creneau2";
    //Créneau 3
    public static final String COLONNE_CRENEAU_3 = "creneau3";
    //Créneau 4
    public static final String COLONNE_CRENEAU_4 = "creneau4";




    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_planning_activity);


        String login = getIntent().getStringExtra("login");
        String date = getIntent().getStringExtra("date");
        String action = getIntent().getStringExtra("action");


        String c1 = "";
        String c2 = "";
        String c3 = "";
        String c4 = "";


        // Récupération BDD
        BDD bddCommunicator = new BDD(ViewPlanningActivity.this,"BDD_TP3",null,1);
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();




        if (Objects.equals(action, "new")) {
            Cursor cPlanning = db.query(TABLE_USER_PLANNING,
                    new String[]{COLONNE_DATE, COLONNE_CRENEAU_1, COLONNE_CRENEAU_2, COLONNE_CRENEAU_3, COLONNE_CRENEAU_4},
                    COLONNE_LOGIN + "='" + login + "' AND " + COLONNE_DATE + " = '" + date + "'", null, null,
                    null, null);
            cPlanning.moveToFirst();
            if (cPlanning.getCount() == 0) {
                Toast.makeText(ViewPlanningActivity.this, "Erreur lors de la récupération de données", Toast.LENGTH_LONG).show();
            }
            c1 = cPlanning.getString(1);
            c2 = cPlanning.getString(2);
            c3 = cPlanning.getString(3);
            c4 = cPlanning.getString(4);
            cPlanning.close();


        } else if (Objects.equals(action, "view")) {

            c1 = getIntent().getStringExtra("c1");
            c2 = getIntent().getStringExtra("c2");
            c3 = getIntent().getStringExtra("c3");
            c4 = getIntent().getStringExtra("c4");

        }




        ((TextView) findViewById(R.id.titreViewPlanning)).append(date);
        ((TextView) findViewById(R.id.creneau1)).setText("\n" + c1 + "\n");
        ((TextView) findViewById(R.id.creneau2)).setText("\n" + c2 + "\n");
        ((TextView) findViewById(R.id.creneau3)).setText("\n" + c3 + "\n");
        ((TextView) findViewById(R.id.creneau4)).setText("\n" + c4 + "\n");


        Button retourPlanning = findViewById(R.id.retourPlanning);
        retourPlanning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(ViewPlanningActivity.this, PlanningActivity.class);
                intent.putExtra("login", login);
                startActivity(intent);

            }
        });


        Button retourMain = findViewById(R.id.retourMainActivity);
        retourMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(ViewPlanningActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }
}
