package com.example.tp3_2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PlanningActivity extends AppCompatActivity {

    // TABLE PLANNING
    private static final String TABLE_USER_PLANNING = "table_user_planning";
    //Login
    public static final String COLONNE_LOGIN = "login";
    //Date
    public static final String COLONNE_DATE = "date";
    //Créneau 1
    public static final String COLONNE_CRENEAU_1 = "creneau1";
    //Créneau 2
    public static final String COLONNE_CRENEAU_2 = "creneau2";
    //Créneau 3
    public static final String COLONNE_CRENEAU_3 = "creneau3";
    //Créneau 4
    public static final String COLONNE_CRENEAU_4 = "creneau4";


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.planning_activity);


        String login = getIntent().getStringExtra("login");

/*
        TextView date = (TextView)findViewById(R.id.date);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                final int year = calendar.get(Calendar.YEAR);
                final int month = calendar.get(Calendar.MONTH);
                final int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(PlanningActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        String formattedDate = String.format("%02d/%02d/%d", selectedDay, selectedMonth + 1, selectedYear);
                    }
                },year, month, day);

                datePickerDialog.show();
            }
        });
*/

        // Récupération BDD
        BDD bddCommunicator = new BDD(PlanningActivity.this,"BDD_TP3",null,1);
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();


        Button valider = findViewById(R.id.valider);
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0){
                boolean planningValide = false;
                TextView errorMsg = findViewById(R.id.errorMsg);

                String date = ((EditText)findViewById(R.id.date)).getText().toString();
                String c1 = ((EditText)findViewById(R.id.creneau1)).getText().toString();
                String c2 = ((EditText)findViewById(R.id.creneau2)).getText().toString();
                String c3 = ((EditText)findViewById(R.id.creneau3)).getText().toString();
                String c4 = ((EditText)findViewById(R.id.creneau4)).getText().toString();

                // Vérifier que cet utilisateur n'a pas déjà saisi un planning pour cette date
                Cursor cPlanning = db.query(TABLE_USER_PLANNING,
                        new String[] {COLONNE_LOGIN},
                        COLONNE_LOGIN + "='" + login + "' AND " + COLONNE_DATE + " = '" + date + "'", null, null,
                        null, null);
                cPlanning.moveToFirst();
                if (cPlanning.getCount() != 0) {
                    errorMsg.setText("Vous avez déjà saisi un planning pour cette date");
                } else {
                    errorMsg.setText("");
                    planningValide = true;
                }
                cPlanning.close();



                if (!planningValide) {
                    Toast.makeText(PlanningActivity.this,"Veillez entrer une date valide !",Toast.LENGTH_LONG).show();
                }else{
                    db.execSQL("INSERT INTO " + TABLE_USER_PLANNING + " ('"
                            + COLONNE_LOGIN + "','" + COLONNE_DATE + "','" + COLONNE_CRENEAU_1 + "','"
                            + COLONNE_CRENEAU_2 + "','" + COLONNE_CRENEAU_3 + "','" + COLONNE_CRENEAU_4
                            + "') VALUES ('"
                            + login + "','" + date + "','" + c1 + "','" + c2 + "','"
                            + c3 + "','" + c4 +"');");


                    Intent intent = new Intent(PlanningActivity.this, ViewPlanningActivity.class);
                    intent.putExtra("action","new");
                    intent.putExtra("login",login);
                    intent.putExtra("date",date);
                    startActivity(intent);
                }
            }
        });





        Button chercher = findViewById(R.id.chercher);
        chercher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0){
                boolean dateValide = false;
                TextView errorMsg = findViewById(R.id.errorMsg);

                String date = ((EditText)findViewById(R.id.dateCherchée)).getText().toString();

                String c1 = "";
                String c2 = "";
                String c3 = "";
                String c4 = "";

                // Vérifier que cet utilisateur a déjà saisi un planning pour cette date
                Cursor cPlanning = db.query(TABLE_USER_PLANNING,
                        new String[] {COLONNE_CRENEAU_1,COLONNE_CRENEAU_2,COLONNE_CRENEAU_3,COLONNE_CRENEAU_4},
                        COLONNE_LOGIN + "='" + login + "' AND " + COLONNE_DATE + " = '" + date + "'", null, null,
                        null, null);
                cPlanning.moveToFirst();
                if (cPlanning.getCount() == 0) {
                    errorMsg.setText("Vous n'avez pas de planning pour cette date");
                } else {
                    errorMsg.setText("");
                    dateValide = true;
                    c1 = cPlanning.getString(0);
                    c2 = cPlanning.getString(1);
                    c3 = cPlanning.getString(2);
                    c4 = cPlanning.getString(3);
                }
                cPlanning.close();


                if (!dateValide) {
                    Toast.makeText(PlanningActivity.this,"Veillez entrer une date valide !",Toast.LENGTH_LONG).show();
                }else{
                    Intent intent = new Intent(PlanningActivity.this, ViewPlanningActivity.class);
                    intent.putExtra("action","view");
                    intent.putExtra("login",login);
                    intent.putExtra("date",date);
                    intent.putExtra("c1",c1);
                    intent.putExtra("c2",c2);
                    intent.putExtra("c3",c3);
                    intent.putExtra("c4",c4);
                    startActivity(intent);
                }
            }
        });
    }
}
