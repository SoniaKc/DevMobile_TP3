package com.example.tp3_2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConnexionActivity extends AppCompatActivity {

    private static final String TABLE_USERS = "table_users";
    public static final String COLONNE_LOGIN = "login";
    public static final String COLONNE_MDP = "mdp";



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connexion_activity);


        // Récupération BDD
        BDD bddCommunicator = new BDD(ConnexionActivity.this,"BDD_TP3",null,1);
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();


        Button connectButton = (Button)findViewById(R.id.connectButton);
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                boolean connexionValide = false;
                TextView errorMsg = findViewById(R.id.errorMsg);
                String login = ((EditText)findViewById(R.id.login)).getText().toString();
                String mdp = ((EditText)findViewById(R.id.mdp)).getText().toString();

                // Vérifier que l'utilisateur existe et que le mdp correspond
                Cursor clogin = db.query(TABLE_USERS,
                        new String[] {COLONNE_LOGIN, COLONNE_MDP},
                        COLONNE_LOGIN + "='" + login + "'" , null, null,
                        null, null);
                clogin.moveToFirst();
                if (clogin.getCount() == 0) {
                    errorMsg.setText("Ce nom d'utilisateur n'exite pas");
                } else if (!clogin.getString(1).equals(mdp)){
                    errorMsg.setText("Le nom d'utilisateur et le mot de passe ne correspondent pas");
                } else {
                    errorMsg.setText("");
                    connexionValide = true;
                }
                clogin.close();

                if (connexionValide){
                    Intent intent = new Intent(ConnexionActivity.this, PlanningActivity.class);
                    intent.putExtra("login",login);
                    startActivity(intent);
                }

            }
        });

    }

}
