package com.example.tp3_2;


import static java.lang.Character.isLetter;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class Fragment1 extends Fragment {
    private static final String TABLE_USERS = "table_users";
    //ID
    public static final String COLONNE_ID = "id";
    //Login
    public static final String COLONNE_LOGIN = "login";
    //Mot de passe
    public static final String COLONNE_MDP = "mdp";
    //Nom
    public static final String COLONNE_NOM = "nom";
    //Prenom
    public static final String COLONNE_PRENOM = "prenom";
    //Date Of Birth
    public static final String COLONNE_DOB = "dob";
    //Telephone
    public static final String COLONNE_TEL = "telephone";
    //Mail
    public static final String COLONNE_MAIL = "mail";

    private static final String TABLE_USER_INTERESTS = "table_user_interests";

    TextView checkLogin;
    TextView checkMDP;
    TextView checkMail;


    public Fragment1(){
        super(R.layout.fragment1);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragment1View = inflater.inflate(R.layout.fragment1, container, false);

        // Création BDD
        BDD bddCommunicator = new BDD(inflater.getContext(),"BDD_TP3",null,1);
        //BDD.dropTables(bddCommunicator.getWritableDatabase());
        bddCommunicator.onCreate(bddCommunicator.getWritableDatabase());
        SQLiteDatabase db = bddCommunicator.getWritableDatabase();


        // Login commence par une lettre, ne dépasse pas 10 caractères, n'existe pas déjà
        checkLogin = (TextView) fragment1View.findViewById(R.id.checkLogin);
        EditText ETlogin = (EditText) fragment1View.findViewById(R.id.login);

        ETlogin.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String login = ETlogin.getText().toString();
                    char firstLetter = login.charAt(0);

                    if (!isLetter(firstLetter)) {
                        checkLogin.setText("Votre nom d'utilisateur doit commencer par une lettre");
                    } else if (login.length() > 10) {
                        checkLogin.setText("Votre nom d'utilisateur ne doit pas dépasser 10 caractères");
                    } else {
                        Cursor clogin = db.query(TABLE_USERS,
                                new String[] {COLONNE_ID},
                                COLONNE_LOGIN + "='" + login + "'" , null, null,
                                null, null);
                        if (clogin.getCount() != 0){
                            checkLogin.setText("Ce nom d'utilisateur est déjà utilisé");
                        }else{
                            checkLogin.setText("");
                        }
                        clogin.close();
                    }
                }
            }
        });

        // Mot de passe fait au moins 8 caractères
        checkMDP = (TextView) fragment1View.findViewById(R.id.checkMDP);
        EditText ETmdp = (EditText) fragment1View.findViewById(R.id.mdp);

        ETmdp.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String mdp = ETmdp.getText().toString();
                    if (mdp.length() < 8) {
                        checkMDP.setText("Votre mot de passe doit faire au moins 8 caractères");
                    } else {
                        checkMDP.setText("");
                    }
                }
            }
        });


        // Adresse mail valide
        checkMail = (TextView) fragment1View.findViewById(R.id.checkMail);
        EditText ETmail = (EditText) fragment1View.findViewById(R.id.mail);

        ETmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String mail = ETmail.getText().toString();
                    if (!mail.contains("@")) {
                        checkMail.setText("Veuillez entrer une adresse mail valide");
                    } else {
                        checkMail.setText("");
                    }
                }
            }
        });




        Button valider = fragment1View.findViewById(R.id.valider);
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                boolean champsValides = true;

                String login = ((EditText) fragment1View.findViewById(R.id.login)).getText().toString();
                Cursor clogin = db.query(TABLE_USERS,
                        new String[] {COLONNE_ID},
                        COLONNE_LOGIN + "='" + login + "'" , null, null,
                        null, null);
                if (!isLetter(login.charAt(0)) && login.length() > 10 && clogin.getCount()!=0){
                    champsValides = false;
                }
                clogin.close();

                String mdp = ((EditText) fragment1View.findViewById(R.id.mdp)).getText().toString();
                if (mdp.length() < 8){
                    champsValides = false;
                }

                String nom = ((EditText) fragment1View.findViewById(R.id.nom)).getText().toString();
                String prenom = ((EditText) fragment1View.findViewById(R.id.prenom)).getText().toString();
                String dob = ((EditText) fragment1View.findViewById(R.id.dob)).getText().toString();
                String tel = ((EditText) fragment1View.findViewById(R.id.tel)).getText().toString();
                String mail = ((EditText) fragment1View.findViewById(R.id.mail)).getText().toString();
                if (!mail.contains("@")) {
                    champsValides = false;
                }


                // Checkboxes des intérêts
                Boolean sport = ((CheckBox) fragment1View.findViewById(R.id.cbSport)).isChecked();
                Boolean musique = ((CheckBox) fragment1View.findViewById(R.id.cbMusique)).isChecked();
                Boolean lecture = ((CheckBox) fragment1View.findViewById(R.id.cbLecture)).isChecked();
                Boolean theatre = ((CheckBox) fragment1View.findViewById(R.id.cbTheatre)).isChecked();
                Boolean photographie = ((CheckBox) fragment1View.findViewById(R.id.cbPhoto)).isChecked();
                Boolean peinture = ((CheckBox) fragment1View.findViewById(R.id.cbPeinture)).isChecked();
                Boolean informatique = ((CheckBox) fragment1View.findViewById(R.id.cbInfo)).isChecked();


                if (!champsValides){
                    Toast.makeText(getContext(),"Veillez entrer des champs valides !",Toast.LENGTH_LONG).show();
                }else{
                    db.execSQL("INSERT INTO " + TABLE_USERS + " ('"
                            + COLONNE_LOGIN + "','" + COLONNE_MDP + "','" + COLONNE_NOM + "','"
                            + COLONNE_PRENOM + "','" + COLONNE_DOB + "','" + COLONNE_TEL + "','"
                            + COLONNE_MAIL + "') VALUES ('"
                            + login + "','" + mdp + "','" + nom + "','" + prenom + "','"
                            + dob + "','" + tel + "','" + mail +"');");


                    if (sport){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Sport');");
                    }
                    if (musique){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Musique');");
                    }
                    if (lecture){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Lecture');");
                    }
                    if (theatre){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Théâtre');");
                    }
                    if (photographie){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Photographie');");
                    }
                    if (peinture){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Peinture');");
                    }
                    if (informatique){
                        db.execSQL("INSERT INTO " + TABLE_USER_INTERESTS + " VALUES ( '"
                                + login + "', 'Informatique');");
                    }


                    // Passage au fragment 2
                    Fragment2 fragment2 = new Fragment2();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragmentCV, fragment2);
                    transaction.addToBackStack(null);
                    transaction.commit();
                }

            }
        });

        return fragment1View;
    }
}
